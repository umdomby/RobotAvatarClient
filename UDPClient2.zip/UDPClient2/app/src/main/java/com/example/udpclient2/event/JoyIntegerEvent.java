package com.example.udpclient2.event;

public class JoyIntegerEvent  extends DataEvent<Integer> {
    public JoyIntegerEvent (int text) {
        super(text);
    }
}