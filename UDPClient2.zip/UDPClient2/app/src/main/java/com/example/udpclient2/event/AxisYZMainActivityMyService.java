package com.example.udpclient2.event;

public class AxisYZMainActivityMyService extends DataEvent<String> {
    public AxisYZMainActivityMyService(String text) {
        super(text);
    }
}
