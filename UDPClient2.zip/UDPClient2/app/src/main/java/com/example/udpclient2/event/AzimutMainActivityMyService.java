package com.example.udpclient2.event;

public class AzimutMainActivityMyService extends DataEvent<String> {
    public AzimutMainActivityMyService(String text) {
        super(text);
    }
}
