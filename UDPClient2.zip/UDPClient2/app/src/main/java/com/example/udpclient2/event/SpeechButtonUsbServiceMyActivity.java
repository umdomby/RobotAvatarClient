package com.example.udpclient2.event;

public class SpeechButtonUsbServiceMyActivity extends DataEvent<String> {
    public SpeechButtonUsbServiceMyActivity(String text) {
        super(text);
    }
}
